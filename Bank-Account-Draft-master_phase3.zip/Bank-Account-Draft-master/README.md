## Bank Account Project Sample

A Simple Project done in Java for learning purposes from our local meetup. 


## Image

![eclipse](https://user-images.githubusercontent.com/11560987/37263323-97038f9c-2575-11e8-9bd5-b8992b7fbb18.PNG)

